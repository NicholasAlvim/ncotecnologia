<script></script>
<template>
    <div class="w-full h-[530px] bg-cyan-950 grid mt-28 relative">
        <h1 class="text-5xl pl-36 pt-8 w-full text-zinc-100 font-semibold absolute text-justify z-50 ">
            Parceiros
        </h1>
        <img src="/assets/transparente_reverso.png" alt="Fundo do Site" width="610" class="opacity-40 absolute ml-36">
        <div class="grid grid-cols-5 justify-items-center mt-32 gap-4 z-50">
            <img src="/assets/parceiros/kaspersky.png" alt="Karpersky" width="150" height="150">
            <img src="/assets/parceiros/lenovo.png" alt="Lenovo" width="150" height="150">

            <div class="bg-zinc-50 w-[150px] h-[150px]">
                <img src="/assets/parceiros/samsung.png" alt="Samsung" width="150" height="150" class="mt-16">
            </div>

            <div class="bg-zinc-50 w-[150px] h-[150px]">
                <img src="/assets/parceiros/intel.png" alt="Intel" width="150" height="150" class="mt-2">
            </div>
            
            <div class="h-[150px]">
                <img src="/assets/parceiros/ibm.jpeg" alt="IBM" width="150" height="150" class="h-full">
            </div>
        </div>

        <!-- <div class="bg-zinc-50 w-[150px] h-[150px]">
                <img src="/assets/parceiros/microsoft.png" alt="Microsoft" width="150" height="150" class="mt-2">
            </div> -->
    </div>
</template>
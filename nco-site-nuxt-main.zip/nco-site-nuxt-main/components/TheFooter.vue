<script setup lang="ts">
import { Instagram, Facebook, Youtube } from 'lucide-vue-next';
const dropdown = () => {

    document.getElementById("myDropdown").classList.toggle("hidden");
}

</script>
<template>
    <footer class="pb-4 bg-gray-100 grid justify-items-center px-10 bg-base-200 text-base-content rounded">
        
        <div class="w-full h-[0.1rem] bg-zinc-300 bg-opacity-90 mb-2 mt-4"></div>
        <div>
            <div class="grid grid-flow-col gap-8 mt-4">
                <a href="#_" class="flex flex-col items-center"><img src="/assets/social/instagram.png" alt="Instagram"
                        width="40" class="hover:shadow-lg">
                    <div class="shadow-lg w-12 h-3"></div>
                </a>


                <a href="#_" class="flex flex-col items-center"><img src="/assets/social/e-mail.png" alt="E-Mail" width="40"
                        class="hover:shadow-lg">
                    <div class="shadow-lg w-12 h-3"></div>
                </a>

                
                <!-- https://wa.me/556892490909?text=ola -->
                <a href="https://wa.me/556892490909" target="_blank" class="flex flex-col items-center"><img src="/assets/social/whatsapp.png" alt="WhatsApp"
                        width="40" class="hover:shadow-lg">
                    <div class="shadow-lg w-12 h-3"></div>
                </a>



            </div>
        </div>
        <div>

            <p class="text-center mt-8">Copyright © 2023 - NCO Tecnologia</p>
        </div>
    </footer>
</template>
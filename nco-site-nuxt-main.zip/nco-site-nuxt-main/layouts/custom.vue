<template>
    <div>
      Some *custom* layout
      <slot />
    </div>
  </template>
  
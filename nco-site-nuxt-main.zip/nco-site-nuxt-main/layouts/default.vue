<template>
    <div>
        <TheHeader />
        <slot />
        <TheFooter />
    </div>
</template>
  
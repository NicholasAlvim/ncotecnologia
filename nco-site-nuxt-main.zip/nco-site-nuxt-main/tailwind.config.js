module.exports = {
    darkMode: 'class',
    // https://tailwindcss.com/docs/font-family
    theme: { fontFamily: { 'nic': ['Oswald'] } }
};

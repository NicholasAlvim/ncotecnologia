<template>
  <div class="bg-gray-100 h-36">
    <div class="grid grid-cols-3">
        <div class="flex justify-start">
            <div>01</div>
            <div>02</div>
            <div>03</div>
        </div> 

        <div class="flex justify-end">
            <div>01</div>
            <div>02</div>
            <div>03</div>
        </div>
    </div>
  </div>
  <div class="grid justify-items-center">
    <div>content</div>
    <div>content</div>
    <div>content</div>

  </div>
  <NuxtLink to="/">home</NuxtLink>
</template>

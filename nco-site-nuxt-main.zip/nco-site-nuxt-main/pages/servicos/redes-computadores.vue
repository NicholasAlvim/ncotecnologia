<template>
    <div>
        redes-computadores
    </div>
</template>
<script setup lang="ts">
useHead({
    title: 'NCO Tecnologia',
    meta: [
        { name: 'description', content: 'Site institucional da empresa NCO Tecnologia' }
    ],
    bodyAttrs: {
        class: 'test'
    },
    //   script: [ { 'data-jsd-embedded': '', 'data-key': 'f84188bd-2e89-4f9c-995a-37a29bbbb581', 'data-base-url': 'https://jsd-widget.atlassian.com', src: 'https://jsd-widget.atlassian.com/assets/embed.js' } ]
})
</script>

<template>
    <div class="bg-gray-100">

        <!-- <NuxtLink to="/about">ab</NuxtLink> -->
        <!-- <NuxtLink :to="{ name: 'about', params: {}}">ab</NuxtLink> -->

        <!-- <NuxtLink to="/dinamico">Parametro dinamico</NuxtLink> -->

        <div class="w-full h-[530px] bg-cyan-950 grid justify-items-center">

            <div class="grid grid-cols-2 text-zinc-100 font-semibold">
                <div class=" w-[38rem]">
                    <div class="h-50 w-80 text-5xl pt-24 text-justify">
                        Você comanda
                        o <span class="text-green-500">seu negócio,</span>
                        enquanto <span class="text-green-500">nós
                            cuidamos </span>da
                        tecnologia
                    </div>
                    <div class="font-normal pt-8">Conheça a Terceirização de TI</div>
                    <div class="pl-8 pt-14">

                        <!-- <NuxtLink to="/servicos/certificado"
                            class="relative inline-flex items-center px-10 py-2 overflow-hidden text-lg font-medium text-green-700 border-2 border-green-700 rounded-xl hover:text-white group hover:bg-gray-50">

                            <span
                                class="absolute left-0 block w-full h-0 transition-all bg-green-700 opacity-100 group-hover:h-full top-1/2 group-hover:top-0 duration-400 ease"></span>

                            <span
                                class="absolute right-0 flex items-center justify-start w-10 h-10 duration-300 transform translate-x-full group-hover:translate-x-0 ease">

                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                                </svg>

                            </span>
                            <span class="relative">Compre agora!</span>
                        </NuxtLink> -->

                    </div>
                </div>
                <div class="w-full flex flex-row-reverse">

                    <img src="/assets/transparente.png" alt="Fundo do Site" width="610" class="">
                </div>
            </div>
        </div>



        <div class="grid justify-items-center">
            <div class="pt-20 font-bold text-5xl  mb-8">Serviços</div>
            <div class="w-full h-[0.1rem] bg-zinc-300 bg-opacity-30 mb-4"></div>
            <div class="grid grid-cols-6 gap-16">

                <NuxtLink to="/servicos/certificado"
                    class="flex flex-col items-center gap-2 p-5 font-normal hover:font-semibold shadow hover:shadow-lg">
                    <img class="hover:opacity-75" src="/assets/icon/suporte/verde/certificado.png" alt="Certificado" width="150" height="150">
                    <span class="text-center">Certificado <br>Digital</span>
                </NuxtLink>

                <NuxtLink to="/servicos/consultoria-contabil"
                    class="flex flex-col items-center gap-2 p-5 font-normal hover:font-semibold shadow hover:shadow-lg">
                    <img class="hover:opacity-75" src="/assets/icon/suporte/verde/contabil.png" alt="Consultoria Contábil" width="150" height="150">
                    <span class="text-center">Consultoria <br>Contábil</span>
                </NuxtLink>

                <NuxtLink to="/servicos/desenvolvimento"
                    class="flex flex-col items-center gap-2 p-5 font-normal hover:font-semibold shadow hover:shadow-lg">
                    <img class="hover:opacity-75" src="/assets/icon/suporte/verde/dev.png" alt="Desenvolvimento" width="150" height="150">
                    <span class="">Desenvolvimento</span>
                </NuxtLink>

                <NuxtLink to="/servicos/designer"
                    class="flex flex-col items-center gap-2 p-5 font-normal hover:font-semibold shadow hover:shadow-lg">
                    <img class="hover:opacity-75" src="/assets/icon/suporte/verde/grafico.png" alt="Designer" width="150" height="150">
                    <span class="text-center">Designer<br>Gráfico</span>
                </NuxtLink>

                <NuxtLink to="/servicos/redes-computadores"
                    class="flex flex-col items-center gap-2 p-5 font-normal hover:font-semibold shadow hover:shadow-lg">
                    <img class="hover:opacity-75" src="/assets/icon/suporte/verde/rede.png" alt="Rede de Computadores" width="150" height="150">
                    <span class="text-center">Redes de <br>Computadores</span>
                </NuxtLink>

                <NuxtLink to="/servicos/suporte"
                    class="flex flex-col items-center gap-4 p-5 font-normal hover:font-semibold shadow hover:shadow-lg">
                    <img class="hover:opacity-75" src="/assets/icon/suporte/verde/suporte.png" alt="Suporte" width="150" height="150">
                    <span class="text-center">Suporte de <br>Informática</span>
                </NuxtLink>

            </div>
        </div>

        <div class="grid justify-items-center">

            <div class="pt-20 font-bold text-5xl mb-8">Compre seu Certificado</div>
            <div class="w-full h-[0.1rem] bg-zinc-300 bg-opacity-30 mb-4"></div>
            <div class="grid grid-cols-4 gap-10">

                <a href="https://cerdigital.gfsis.com.br/gestaofacil/loja/index?local=500&indicacao=213578#"
                    target="_blank">
                    <img class="hover:opacity-75" src="/assets/icon/certificado/a1-cpf.png" alt="A1 CPF" width="275" height="275"></a>

                <a href="https://cerdigital.gfsis.com.br/gestaofacil/loja/index?local=500&indicacao=213578#"
                    target="_blank">
                    <img class="hover:opacity-75" src="/assets/icon/certificado/a3-cpf.png" alt="A3 CPF" width="275" height="275"></a>

                <a href="https://cerdigital.gfsis.com.br/gestaofacil/loja/index?local=500&indicacao=213578#"
                    target="_blank">
                    <img class="hover:opacity-75" src="/assets/icon/certificado/a1-cnpj.png" alt="A1 CNPJ" width="275"
                        height="275"></a>

                <a href="https://cerdigital.gfsis.com.br/gestaofacil/loja/index?local=500&indicacao=213578#"
                    target="_blank">
                    <img class="hover:opacity-75" src="/assets/icon/certificado/a3-cnpj.png" alt="A3 CNPJ" width="275" height="275"></a>


            </div>
        </div>



        <Parceiros></Parceiros>

        <div class="grid grid-cols-2 grid justify-items-center mt-8">

            <div class="border-2 p-1 w-[610px]">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3929.619100432185!2d-67.80849782404597!3d-9.965614406652465!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x917f8cf9b6888ab9%3A0xad599e725c977e53!2sEstr.%20do%20Avi%C3%A1rio%2C%20636%20-%20Capoeira%2C%20Rio%20Branco%20-%20AC%2C%2069900-854!5e0!3m2!1sen!2sbr!4v1691167022565!5m2!1sen!2sbr"
                    width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>

            <div class="m-2 text-justify">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Soluta eveniet dolore
                excepturi accusantium eum ad amet temporibus neque alias, rerum quisquam ducimus. Adipisci minus nobis non
                omnis autem rem amet.</div>
    </div>
</div></template>

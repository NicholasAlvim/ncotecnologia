<script setup lang="ts">

</script>

<template>
    <div class="mx-24 mt-14 text-justify mb-8">
        <h2 class="font-bold text-2xl font-nic">Descrição:</h2>
        <p class="m-4">A <span class="font-bold text-lg italic text-green-500">NCO Tecnologia</span> é uma empresa líder no setor de Tecnologia da Informação (TI), especializada em fornecer soluções abrangentes e inovadoras para suporte de micro informática e serviços de certificação digital. Com uma experiência sólida e um compromisso contínuo com a excelência, a <span class="font-bold text-lg italic text-green-500">NCO Tecnologia</span> se destaca como parceira confiável para empresas e indivíduos que buscam otimizar suas operações tecnológicas e garantir a segurança de suas transações digitais.</p>

        <h2 class="font-bold text-2xl mt-14">Principais Serviços:</h2>
        <p class="m-4"><span class="text-xl">Suporte a Micro Informática:</span> A <span class="font-bold text-lg italic text-green-500">NCO Tecnologia</span> oferece uma ampla gama de serviços de suporte técnico para micro informática. Seja para empresas de pequeno porte ou indivíduos, nossa equipe altamente qualificada está pronta para lidar com problemas técnicos, configurações, atualizações de software, diagnósticos de hardware e muito mais. Nossos serviços de suporte visam manter os sistemas funcionando sem problemas, aumentando a produtividade e reduzindo o tempo de inatividade.</p>

        
        <p class="m-4"><span class="text-xl">Certificação Digital:</span> Como uma autoridade confiável em certificação digital, a <span class="font-bold text-lg italic text-green-500">NCO Tecnologia</span> oferece soluções seguras para autenticação e assinatura eletrônica. Nossos serviços de certificação digital ajudam empresas e indivíduos a estabelecerem identidades digitais confiáveis, garantindo a integridade e a autenticidade de documentos e transações online. Nossos certificados digitais são reconhecidos internacionalmente e atendem aos mais altos padrões de segurança.</p>

        <h4 class="font-bold text-2xl mt-14">Diferenciais:</h4>
        <p class="m-4"><span class="text-xl">Expertise Técnica:</span> Nossa equipe é composta por profissionais experientes e apaixonados por tecnologia. Estamos sempre atualizados com as últimas tendências e avanços na área de TI, permitindo que forneçamos soluções de ponta aos nossos clientes.</p>

        <p class="m-4"><span class="text-xl">Segurança em Primeiro Lugar:</span> Reconhecemos a importância da segurança digital em um mundo cada vez mais conectado. Nossos serviços de certificação digital e as práticas de segurança que implementamos em nossos suportes refletem nosso compromisso em proteger os dados e a privacidade dos nossos clientes.</p>

        <p class="m-4"><span class="text-xl">Inovação Contínua:</span> A <span class="font-bold text-lg italic text-green-500">NCO Tecnologia</span> está constantemente buscando novas maneiras de melhorar e inovar. Abraçamos as mudanças tecnológicas e procuramos implementar as soluções mais recentes para garantir que nossos clientes estejam à frente no cenário digital em constante evolução.</p>

        <h4 class="font-bold text-2xl mt-14">Missão:</h4>
        <p class="m-4">Nossa missão na <span class="font-bold text-lg italic text-green-500">NCO Tecnologia</span> é capacitar indivíduos e empresas a alcançarem seus objetivos por meio de soluções de tecnologia confiáveis e de alto desempenho. Estamos comprometidos em oferecer serviços excepcionais que otimizem a eficiência operacional e garantam a segurança digital.</p>

        <h4 class="font-bold text-2xl mt-14">Visão:</h4>
        <p class="m-4">Buscamos ser reconhecidos como líderes no fornecimento de serviços de suporte a micro informática e certificação digital, elevando os padrões do setor por meio de nossa excelência técnica e compromisso com a inovação.</p>


        <p class="mt-14 text-3xl">A <span class="font-bold italic text-green-500">NCO Tecnologia</span> é a escolha ideal para aqueles que procuram parceiros confiáveis para suas necessidades de TI e segurança digital. Com nossa experiência e dedicação, estamos prontos para enfrentar os desafios tecnológicos em constante evolução e oferecer soluções que impulsionam o sucesso de nossos clientes.</p>

        
    </div>
</template>	